For Project 3 I(Marisa Mills) worked with Erik Eskeland

I worked on question 1 and 4 
Erik worked on 2 and 3

I went back wrote the solution file and did testing then made 
minor changes to a few of our solutions

The output is based on the code I commented out at the bottom of cspSolutions.py
It was giving me weird errors in grade scope so I took it off but running 


>python cspSolution.py | find "solution"

Is how I got the output
